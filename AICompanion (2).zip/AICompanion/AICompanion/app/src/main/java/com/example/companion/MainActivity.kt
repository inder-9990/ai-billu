package com.example.companion

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/** Setup screen for Billu: API key, behaviour, permissions, start and stop. */
class MainActivity : Activity() {

    private val grey = 0xFF5F6368.toInt()

    private lateinit var keyInput: EditText
    private lateinit var overlayStatus: TextView
    private lateinit var a11yStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun buildUi(): ScrollView {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(32), dp(20), dp(32))
        }

        col.addView(label(Billu.NAME, 28f, bold = true))
        col.addView(label(
            "A ginger cat who lives on your screen. He walks along the edges when he's awake, " +
                "naps when left alone, and stays out of your way while you work.",
            14f, topDp = 4, color = grey
        ))
        col.addView(CatView(this).apply { mood = CatView.Mood.IDLE }, LinearLayout.LayoutParams(dp(140), dp(140)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            topMargin = dp(12)
        })

        col.addView(section("1. Claude API key (optional)"))
        keyInput = EditText(this).apply {
            hint = "sk-ant-…"
            setText(Prefs.apiKey(this@MainActivity))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine(true)
        }
        col.addView(keyInput)
        col.addView(label(
            "Without a key Billu still works offline with his help library. With a key and internet, he can chat freely. The key is stored only on this phone.",
            12f, color = grey
        ))

        col.addView(section("2. Behaviour"))
        col.addView(switchRow("Walk along the screen edges", Prefs.roam(this)) { Prefs.setRoam(this, it) })
        col.addView(switchRow("Speak replies out loud", Prefs.voice(this)) { Prefs.setVoice(this, it) })
        col.addView(switchRow("Random meows and remarks", Prefs.chatter(this)) { Prefs.setChatter(this, it) })

        col.addView(section("3. Permissions"))
        overlayStatus = label("", 14f)
        col.addView(overlayStatus)
        col.addView(button("Allow display over other apps") { openOverlaySettings() })
        a11yStatus = label("", 14f, topDp = 12)
        col.addView(a11yStatus)
        col.addView(button("Enable problem detection (optional)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(label(
            "Problem detection lets Billu notice crash and error screens. Battery, network and storage warnings work without it.",
            12f, color = grey
        ))

        col.addView(section("4. Go!"))
        col.addView(button("Start Billu") { start() })
        col.addView(button("Stop Billu") {
            stopService(Intent(this, FloatingService::class.java))
            toast("Billu is asleep. Bye for now.")
        })

        return ScrollView(this).apply {
            setBackgroundColor(0xFFF7F7FB.toInt())
            addView(col)
        }
    }

    private fun switchRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit) = Switch(this).apply {
        text = title
        textSize = 15f
        isChecked = checked
        setPadding(0, dp(10), 0, dp(10))
        setOnCheckedChangeListener { _, value -> onChange(value) }
    }

    private fun start() {
        Prefs.setApiKey(this, keyInput.text.toString())
        if (!Settings.canDrawOverlays(this)) {
            toast("Please allow 'Display over other apps' first")
            openOverlaySettings()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        startForegroundService(Intent(this, FloatingService::class.java))
        toast("${Billu.NAME} is on your screen")
        moveTaskToBack(true)
    }

    private fun openOverlaySettings() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    private fun refreshStatus() {
        val overlay = Settings.canDrawOverlays(this)
        overlayStatus.text = if (overlay) "✅ Display over other apps: allowed" else "⬜ Display over other apps: not allowed yet"
        a11yStatus.text = if (isAccessibilityOn()) "✅ Problem detection: on" else "⬜ Problem detection: off (optional)"
    }

    private fun isAccessibilityOn(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        val cn = ComponentName(this, ProblemWatcherService::class.java)
        return enabled.split(':').any {
            it.equals(cn.flattenToString(), ignoreCase = true) || it.equals(cn.flattenToShortString(), ignoreCase = true)
        }
    }

    // ---- small UI helpers

    private fun section(text: String) = label(text, 18f, bold = true, topDp = 24)

    private fun label(text: String, size: Float, bold: Boolean = false, topDp: Int = 0, color: Int = Color.BLACK) =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(topDp), 0, dp(4))
        }

    private fun button(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
