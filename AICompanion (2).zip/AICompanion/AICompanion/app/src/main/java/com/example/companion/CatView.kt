package com.example.companion

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.CornerPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.sin

class CatView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    var state: CatState = CatState.IDLE
        set(value) {
            field = value
            postInvalidateOnAnimation()
        }

    private var tailPhase = 0f

    private val animator = ValueAnimator.ofFloat(0f, (2 * Math.PI).toFloat()).apply {
        duration = 2000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { anim ->
            tailPhase = anim.animatedValue as Float
            invalidate()
        }
    }

    // Paints
    private val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#1C1B20") // Charcoal black
        style = Paint.Style.FILL
    }

    private val innerEarPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#8E6B8E") // Soft mauve inner ear
        style = Paint.Style.FILL
    }

    private val eyeWhitePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }

    private val pupilPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#121115")
        style = Paint.Style.FILL
    }

    private val nosePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#E5989B") // Soft pink nose
        style = Paint.Style.FILL
    }

    private val collarPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#C0392B") // Classic red collar
        style = Paint.Style.FILL
    }

    private val bellPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#F1C40F") // Gold bell
        style = Paint.Style.FILL
    }

    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#121115")
        style = Paint.Style.STROKE
        strokeWidth = 3f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    private val tailPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#1C1B20")
        style = Paint.Style.STROKE
        strokeWidth = 14f
        strokeCap = Paint.Cap.ROUND
        pathEffect = CornerPathEffect(10f)
    }

    private val whiskerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#2C2C2C")
        style = Paint.Style.STROKE
        strokeWidth = 2.5f
        strokeCap = Paint.Cap.ROUND
    }

    // Paths
    private val outerEarLeft = Path()
    private val outerEarRight = Path()
    private val innerEarLeft = Path()
    private val innerEarRight = Path()
    private val bodyPath = Path()
    private val tailPath = Path()

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val w = width.toFloat()
        val h = height.toFloat()
        val centerX = w / 2f
        val centerY = h / 2f

        // Draw animated tail
        tailPath.reset()
        val tailBaseX = centerX + 18f
        val tailBaseY = centerY + 38f
        val tailSwing = sin(tailPhase.toDouble()).toFloat() * 12f

        tailPath.moveTo(tailBaseX, tailBaseY)
        tailPath.cubicTo(
            tailBaseX + 25f + tailSwing, tailBaseY - 10f,
            tailBaseX + 35f + tailSwing, tailBaseY - 35f,
            tailBaseX + 20f + (tailSwing * 1.2f), tailBaseY - 50f
        )
        canvas.drawPath(tailPath, tailPaint)

        // Seated Body Shape
        bodyPath.reset()
        bodyPath.moveTo(centerX - 22f, centerY + 10f)
        bodyPath.cubicTo(
            centerX - 28f, centerY + 25f,
            centerX - 30f, centerY + 45f,
            centerX - 24f, centerY + 52f
        )
        bodyPath.lineTo(centerX + 24f, centerY + 52f)
        bodyPath.cubicTo(
            centerX + 30f, centerY + 45f,
            centerX + 28f, centerY + 25f,
            centerX + 22f, centerY + 10f
        )
        bodyPath.close()
        canvas.drawPath(bodyPath, bodyPaint)

        // Paws
        canvas.drawCircle(centerX - 12f, centerY + 50f, 7f, bodyPaint)
        canvas.drawCircle(centerX + 12f, centerY + 50f, 7f, bodyPaint)

        // Collar & Bell
        val collarRect = RectF(centerX - 18f, centerY + 6f, centerX + 18f, centerY + 12f)
        canvas.drawRoundRect(collarRect, 3f, 3f, collarPaint)
        canvas.drawCircle(centerX, centerY + 13f, 4.5f, bellPaint)
        canvas.drawCircle(centerX, centerY + 13f, 4.5f, strokePaint)

        // Pointy Anime Ears
        val headCenterY = centerY - 15f

        // Left Ear
        outerEarLeft.reset()
        outerEarLeft.moveTo(centerX - 24f, headCenterY - 5f)
        outerEarLeft.lineTo(centerX - 34f, headCenterY - 48f)
        outerEarLeft.lineTo(centerX - 8f, headCenterY - 22f)
        outerEarLeft.close()

        innerEarLeft.reset()
        innerEarLeft.moveTo(centerX - 22f, headCenterY - 8f)
        innerEarLeft.lineTo(centerX - 30f, headCenterY - 40f)
        innerEarLeft.lineTo(centerX - 11f, headCenterY - 20f)
        innerEarLeft.close()

        // Right Ear
        outerEarRight.reset()
        outerEarRight.moveTo(centerX + 24f, headCenterY - 5f)
        outerEarRight.lineTo(centerX + 34f, headCenterY - 48f)
        outerEarRight.lineTo(centerX + 8f, headCenterY - 22f)
        outerEarRight.close()

        innerEarRight.reset()
        innerEarRight.moveTo(centerX + 22f, headCenterY - 8f)
        innerEarRight.lineTo(centerX + 30f, headCenterY - 40f)
        innerEarRight.lineTo(centerX + 11f, headCenterY - 20f)
        innerEarRight.close()

        canvas.drawPath(outerEarLeft, bodyPaint)
        canvas.drawPath(innerEarLeft, innerEarPaint)
        canvas.drawPath(outerEarRight, bodyPaint)
        canvas.drawPath(innerEarRight, innerEarPaint)

        // Head
        val headRadius = 26f
        canvas.drawCircle(centerX, headCenterY, headRadius, bodyPaint)

        // Eyes based on state
        when (state) {
            CatState.SPEAKING -> {
                val leftEyeX = centerX - 11f
                val rightEyeX = centerX + 11f
                val eyeY = headCenterY - 2f

                canvas.drawCircle(leftEyeX, eyeY, 8.5f, eyeWhitePaint)
                canvas.drawCircle(rightEyeX, eyeY, 8.5f, eyeWhitePaint)

                canvas.drawCircle(leftEyeX + 1f, eyeY, 5f, pupilPaint)
                canvas.drawCircle(rightEyeX - 1f, eyeY, 5f, pupilPaint)

                canvas.drawCircle(leftEyeX - 1.5f, eyeY - 2f, 2.5f, eyeWhitePaint)
                canvas.drawCircle(rightEyeX - 3.5f, eyeY - 2f, 2.5f, eyeWhitePaint)

                val mouthPath = Path().apply {
                    moveTo(centerX - 4f, headCenterY + 11f)
                    quadTo(centerX, headCenterY + 17f, centerX + 4f, headCenterY + 11f)
                    close()
                }
                canvas.drawPath(mouthPath, innerEarPaint)
            }
            CatState.THINKING -> {
                val leftEyeX = centerX - 11f
                val rightEyeX = centerX + 11f
                val eyeY = headCenterY - 2f

                canvas.drawCircle(leftEyeX, eyeY, 8.5f, eyeWhitePaint)
                canvas.drawCircle(rightEyeX, eyeY, 8.5f, eyeWhitePaint)

                canvas.drawCircle(leftEyeX + 1f, eyeY - 2f, 5f, pupilPaint)
                canvas.drawCircle(rightEyeX + 1f, eyeY - 2f, 5f, pupilPaint)

                canvas.drawCircle(leftEyeX, eyeY - 3f, 2.5f, eyeWhitePaint)
                canvas.drawCircle(rightEyeX, eyeY - 3f, 2.5f, eyeWhitePaint)
            }
            CatState.IDLE, CatState.LISTENING -> {
                val leftEyeX = centerX - 11f
                val rightEyeX = centerX + 11f
                val eyeY = headCenterY - 2f

                canvas.drawCircle(leftEyeX, eyeY, 8.5f, eyeWhitePaint)
                canvas.drawCircle(rightEyeX, eyeY, 8.5f, eyeWhitePaint)

                canvas.drawCircle(leftEyeX, eyeY, 5f, pupilPaint)
                canvas.drawCircle(rightEyeX, eyeY, 5f, pupilPaint)

                canvas.drawCircle(leftEyeX - 2f, eyeY - 2f, 2.5f, eyeWhitePaint)
                canvas.drawCircle(rightEyeX - 2f, eyeY - 2f, 2.5f, eyeWhitePaint)
            }
            CatState.WALKING -> {
                val eyeY = headCenterY - 2f
                val happyLeft = Path().apply {
                    moveTo(centerX - 16f, eyeY)
                    quadTo(centerX - 11f, eyeY - 6f, centerX - 6f, eyeY)
                }
                val happyRight = Path().apply {
                    moveTo(centerX + 6f, eyeY)
                    quadTo(centerX + 11f, eyeY - 6f, centerX + 16f, eyeY)
                }
                canvas.drawPath(happyLeft, strokePaint)
                canvas.drawPath(happyRight, strokePaint)
            }
        }

        // Nose
        val nosePath = Path().apply {
            moveTo(centerX - 2.5f, headCenterY + 5f)
            lineTo(centerX + 2.5f, headCenterY + 5f)
            lineTo(centerX, headCenterY + 7.5f)
            close()
        }
        canvas.drawPath(nosePath, nosePaint)

        // Whiskers
        val whiskerY = headCenterY + 7f
        canvas.drawLine(centerX - 14f, whiskerY - 2f, centerX - 32f, whiskerY - 6f, whiskerPaint)
        canvas.drawLine(centerX - 14f, whiskerY + 2f, centerX - 30f, whiskerY + 5f, whiskerPaint)
        canvas.drawLine(centerX + 14f, whiskerY - 2f, centerX + 32f, whiskerY - 6f, whiskerPaint)
        canvas.drawLine(centerX + 14f, whiskerY + 2f, centerX + 30f, whiskerY + 5f, whiskerPaint)
    }
}