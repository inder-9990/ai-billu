package com.example.companion

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Minimal Claude Messages API client. The API key is supplied by the user and stored only on the device. */
object AiClient {
    // Fast, low-cost model suits a quick companion. Change to another model ID if you prefer.
    const val MODEL = "claude-haiku-5-5"

    suspend fun chat(
        apiKey: String,
        system: String,
        history: List<Pair<String, String>>
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            // The API requires the first message to be from the user.
            val msgs = history.dropWhile { it.first != "user" }
            require(msgs.isNotEmpty()) { "Nothing to send" }

            val messages = JSONArray()
            msgs.forEach { (role, text) ->
                messages.put(JSONObject().put("role", role).put("content", text))
            }
            val body = JSONObject()
                .put("model", MODEL)
                .put("max_tokens", 400)
                .put("system", system)
                .put("messages", messages)

            val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
            try {
                conn.requestMethod = "POST"
                conn.connectTimeout = 15_000
                conn.readTimeout = 45_000
                conn.doOutput = true
                conn.setRequestProperty("content-type", "application/json")
                conn.setRequestProperty("x-api-key", apiKey)
                conn.setRequestProperty("anthropic-version", "2023-06-01")
                conn.outputStream.use { it.write(body.toString().toByteArray()) }

                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                if (code !in 200..299) {
                    val msg = runCatching { JSONObject(text).getJSONObject("error").getString("message") }
                        .getOrDefault("HTTP $code")
                    error(msg)
                }
                val content = JSONObject(text).getJSONArray("content")
                buildString {
                    for (i in 0 until content.length()) {
                        val block = content.getJSONObject(i)
                        if (block.optString("type") == "text") append(block.getString("text"))
                    }
                }.trim().ifEmpty { error("Empty reply") }
            } finally {
                conn.disconnect()
            }
        }
    }
}
