package com.example.companion

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

/** Speaks replies with each character's pitch and speed, using the phone's built-in voice (works offline). */
class Voice(context: Context) {

    private var ready = false
    private val tts: TextToSpeech = TextToSpeech(context.applicationContext) { status ->
        ready = status == TextToSpeech.SUCCESS
    }

    fun speak(text: String, pitch: Float, rate: Float, hindi: Boolean = false) {
        if (!ready) return
        runCatching {
            val hindiLocale = Locale("hi", "IN")
            val locale = if (hindi && tts.isLanguageAvailable(hindiLocale) >= TextToSpeech.LANG_AVAILABLE) {
                hindiLocale
            } else {
                Locale.US
            }
            tts.language = locale
            tts.setPitch(pitch)
            tts.setSpeechRate(rate)
            tts.speak(text.take(300), TextToSpeech.QUEUE_FLUSH, null, "companion")
        }
    }

    fun shutdown() {
        runCatching {
            tts.stop()
            tts.shutdown()
        }
    }
}
